# Brand Context

## Brand
- **Name**: RelayDesk (fictional)
- **Category**: Client project coordination software
- **Description**: One shared project space for client approvals and handoff decisions.
- **Stage**: Pre-launch
- **Website**: N/A — fictional example

## Audience
- **Primary Audience**: Small English-speaking agencies managing client approvals
- **Key Problem**: Approval decisions scattered across email and project notes
- **Their Language**: Working phrase: one place for client decisions; not an interview quote

## Positioning
- **Differentiation**: Working hypothesis: approvals and handoff notes in one shared project space.
- **Competitors**: Unknown — research required; no comparison claims approved.
- **Market Position**: Niche — planning assumption

## Brand Personality
- **Personality Words**: Calm, clear, practical
- **Tone**: Professional and formal.
- **Voice Admires**: None supplied

## Values & Mission
- **Core Values**: Clarity, accountability, simplicity
- **Mission**: Help small agencies make project decisions easier to find.

## Goals
- **Primary Goal**: Learn whether small agencies need this workflow; fictional planning objective.
- **Key Metrics**: Discovery interviews completed and qualified signups; no targets or results supplied.
